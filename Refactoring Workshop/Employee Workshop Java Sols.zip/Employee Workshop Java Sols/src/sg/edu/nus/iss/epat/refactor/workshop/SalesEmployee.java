package sg.edu.nus.iss.epat.refactor.workshop;

public class SalesEmployee extends Employee {
	private float commissionRate;
	private int salesMade;
	
	public SalesEmployee (String name, float salary, 
                            float commissionRate, int salesMade){
		super(name, salary);
		this.commissionRate = commissionRate;
		this.salesMade = salesMade;
	}
	
	protected float variableComponent() {
		return salesMade*commissionRate;
	}
}

