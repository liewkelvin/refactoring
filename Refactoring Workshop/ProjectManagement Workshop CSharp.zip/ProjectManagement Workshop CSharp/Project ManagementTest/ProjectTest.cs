﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProjectManagement;

namespace Project_ManagementTest
{
   [TestClass]
   public class ProjectTest
   {
      private const string MEMBER_NAME1 = "Anne";
      private const string MEMBER_NAME2 = "John";

      private Project project = null;

      [TestInitialize]
      public void Initialize()
      {
         project = new Project();
      }
      [TestMethod]
      public void TestAddMember()
      {
         project.AddMember(MEMBER_NAME1);
         project.AddMember(MEMBER_NAME2);

         Assert.AreEqual(2, project.Members.Count);
         Assert.IsTrue(project.Members.Contains(MEMBER_NAME1));
         Assert.IsTrue(project.Members.Contains(MEMBER_NAME2));
      }

      [TestMethod]
      public void TestRemoveMember1()
      {
         //One member added; one removed
         project.AddMember(MEMBER_NAME1);

         project.RemoveMember(MEMBER_NAME1);

         Assert.AreEqual(0, project.Members.Count);
      }

      [TestMethod]
      public void TestRemoveMember2()
      {
         //Two members added; one removed
         project.AddMember(MEMBER_NAME1);
         project.AddMember(MEMBER_NAME2);

         project.RemoveMember(MEMBER_NAME1);

         Assert.AreEqual(1, project.Members.Count);
         Assert.IsFalse(project.Members.Contains(MEMBER_NAME1));
         Assert.IsTrue(project.Members.Contains(MEMBER_NAME2));
      }
   }
}
