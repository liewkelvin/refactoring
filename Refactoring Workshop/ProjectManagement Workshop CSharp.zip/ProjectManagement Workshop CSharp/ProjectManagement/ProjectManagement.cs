﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement
{
   public class Duration
   {
      public DateTime From { get; set; }
      public DateTime To { get; set; }
   }

   public class Project
   {
      private List<string> members;
      private string manager = null;

      public Project()
      {
         members = new List<string>();
      }

      public virtual void AddMember(string member)
      {
         members.Add(member);
      }

      public virtual string RemoveMember(string member)
      {
         members.Remove(member);
         return member;
      }

      public void AddManager(string manager)
      {
         this.manager = manager;
      }

      public string Name { get; set; }
      public Duration ProjectDuration { get; set; }
      public double Rate { get; set; }
      public int EffortRequired { get; set; }

      public List<string> Members
      {
         get
         {
            return members;
         }
      }

      public string Manager
      {
         get
         {
            return manager;
         }
      }
   }

   public class SubContractedProject : Project
   {
      public override void AddMember(string member)
      {
      }

      public override string RemoveMember(string member)
      {
         return null;
      }

      public string SubContractedCompany { get; set; }

      public string ContactPerson { get; set; }
   }

}
