﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EmployeeNS;

namespace EmployeeTest
{
   [TestClass]
   public class SalesEmployeeTest
   {
      [TestMethod]
      public void TestComputeSalary()
      {
         SalesEmployee salesEmployee = new SalesEmployee("Jack", 2000.0f, 300.0f, 20);
         Assert.IsTrue(salesEmployee.ComputeSalary() == 7600.0);
      }
   }
}
