﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EmployeeNS;

namespace EmployeeTest
{
   [TestClass]
   public class ManagerTest
   {
      [TestMethod]
      public void TestComputeSalary()
      {
         Employee manager = new Manager("John", 5000.0f, 2000.0f);
         Assert.IsTrue(manager.ComputeSalary() == 6000.0f);
      }
   }
}
