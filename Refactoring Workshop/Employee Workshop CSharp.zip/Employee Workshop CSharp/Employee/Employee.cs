﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeNS
{
   public abstract class Employee
   {
      public string Name { set; get; }
      public float Salary { set; get; }

      public Employee(string name, float salary)
      {
         Name = name;
         Salary = salary;
      }

      protected float ComputeDeductions() { return Salary * 0.2f; }

      public abstract float ComputeSalary();
   }

   public class Manager : Employee
   {
      public float VariableComponent { set; get; }

      public Manager(string name, float salary, float variableComponent)
          : base(name, salary)
      {
         VariableComponent = variableComponent;
      }

      public override float ComputeSalary()
      {
         return Salary - ComputeDeductions() + VariableComponent;
      }
   }


   public class SalesEmployee : Employee
   {
      public float CommissionRate { set; get; }
      
      public int SalesMade { set; get; }
      
      public SalesEmployee(string name, float salary, float commissionRate, int salesMade)
          : base(name, salary)
      {
         CommissionRate = commissionRate;
         SalesMade = salesMade;
      }

      private float GetVariableComponent()
      {
         return SalesMade * CommissionRate;
      }

      public override float ComputeSalary()
      {
         return Salary - ComputeDeductions() + GetVariableComponent();
      }
   }

}
