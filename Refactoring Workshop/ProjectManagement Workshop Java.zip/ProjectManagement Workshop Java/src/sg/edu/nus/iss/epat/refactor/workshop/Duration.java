package sg.edu.nus.iss.epat.refactor.workshop;

import java.util.Calendar;

public class Duration {
	private Calendar from;
	private Calendar to;

	public Calendar getFrom() {
		return from;
	}

	public void setFrom(Calendar from) {
		this.from = from;
	}

	public Calendar getTo() {
		return to;
	}

	public void setTo(Calendar to) {
		this.to = to;
	}

}
